const saveOptions = () => {
    const thirdParty = document.getElementById('third-party').checked;
    const dataCollection = document.getElementById('data-collection').checked;
    const activityTracking = document.getElementById('activity-tracking').checked;

    chrome.storage.sync.set(
      { thirdParty: thirdParty, dataCollection: dataCollection, activityTracking: activityTracking

      }).then(
      () => {
        // Update status to let user know options were saved.
        const status = document.getElementById('status');
        status.textContent = 'Options saved.';
        setTimeout(() => {
          status.textContent = '';
        }, 750);
      }
    );
  };


const restoreOptions = () => {
    chrome.storage.sync.get(
      { thirdParty: true, dataCollection: true, activityTracking: true }).then((items) => {
      document.getElementById('third-party').checked = items.thirdParty;
      document.getElementById('data-collection').checked = items.dataCollection;
      document.getElementById('activity-tracking').checked = items.activityTracking;
      }
    );
  };
  
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);